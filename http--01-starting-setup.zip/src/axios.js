import axios from 'axios';

//create a instance of axios
const instance = axios.create({
    baseURL:'https://jsonplaceholder.typicode.com'
});

instance.axios.defaults.headers.common['Authorization'] = 'AUTH TOKEN FROM INSTANCE';

export default instance;