import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import axios from 'axios';

axios.defaults.baseURL = 'https://jsonplaceholder.typicode.com';
axios.defaults.headers.common['Authorization'] = 'AUTH TOKEN';
axios.defaults.headers.post['Content-Type'] = 'application/json';

//interceptors will run in every http action/request
axios.interceptors.request.use(request => {
    console.log(request);
    //you can also edit the request before returning it
    return request; //should always return, otherwise will block it
}, error => { //this errors has to do with internet problems and things envolved in the http request!!
    console.log(error+' [request]');
    return Promise.reject(error);
});


axios.interceptors.response.use(response => {
    console.log(response); 
    return response; 
}, error => { 
    console.log(error+' [response]');
    return Promise.reject(error);
});

ReactDOM.render( <App />, document.getElementById( 'root' ) );
registerServiceWorker();
