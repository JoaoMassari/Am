import React, { Component } from 'react';
import axios from '../../axios-order';

import './NewPost.css';

class NewPost extends Component {
    state = {
        title: '',
        content: '',
        author: 'Max',
        posting: false,
    }
    shouldComponentUpdate(nextProps, nextState) {
        if(this.state.posting === true){
            return true
        }

    }
    componentDidUpdate() {
        console.log('[NewPost]')
    }

    postDataHandler = () => {
        
        this.setState({posting: true}), console.log('teste')
        //this is an object, but remember, axios axios will turn automatically the data into json in the 2° parameter below
        const data = {
           title: this.state.title,
           body: this.state.content,
           author: this.state.author 
        };
        axios.post('/posts.json', data)//2° argument is the data we want to send... VERY IMPORTANT - AXIOS AUTOMATICALLY STRINGFY THE DATA, .json is specifically needed in firebase
        .then(response => {
            console.log(response);
        }).catch(error =>{
            console.log(error);
        }); 
    }

    render () {
        return (
            <div className="NewPost">
                <h1>Adicione dados</h1>
                <label>Titulo</label>
                <input type="text" value={this.state.title} onChange={(event) => this.setState({title: event.target.value, posting: true})} />
                <label>descrição</label>
                <textarea rows="4" value={this.state.content} onChange={(event) => this.setState({content: event.target.value, posting: true})} />
                <label>Autor</label>
                <select value={this.state.author} onChange={(event) => this.setState({author: event.target.valu, posting: true})}>
                    <option value="Max">Max</option>
                    <option value="Manu">Manu</option>
                </select>
                <button onClick={this.postDataHandler }>adicionar</button>
            </div>
        );
    }
}

export default NewPost;